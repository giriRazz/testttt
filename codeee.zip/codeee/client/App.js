import TestBlok from './components/TestBlok';
import Loginn from './components/Login';
import { BlogPara } from './CommonElements';
import {BrowserRouter, Route, Routers, Routes} from "react-router-dom";
import Registration from './components/Registration';
import Login from './components/Login';


function App() {
  return (
    <>

      <BrowserRouter>
          <Routes>
              <Route  exact path="/" element = {<Registration/>} /> 
              <Route  exact path="/login" element = {<Login/>} /> 
          </Routes>

      </BrowserRouter>
    
    </>
  );
}

export default App;
