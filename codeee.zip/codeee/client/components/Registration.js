import React from 'react'
import axios from 'axios'
import  { useState } from 'react';


const Registration = () => {


    const [userdt, setUserdt] = useState({
        user_name: '',
        user_email: '',
        gender: '',
        user_dob: '',
        password: '',
      });
 



const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserdt({
      ...userdt,
      [name]: value,
    });
  };

const handleSubmit = async(e) =>{
    e.preventDefault();
    
    try {
        const res = await axios.post(`http://localhost:8000/api/user/adduser`,userdt);

        console.log(res)
       
    } catch (error) {
        console.log(error)
    }
}



  return (
    <div>
     <form onSubmit={handleSubmit}>
         <table align='center'>
            <tr>
                <td>Username</td>
                <td>
                    <input type="text" name="user_name" onChange={handleInputChange}/>
                </td>
            </tr>
            <tr>
                <td>user_email</td>
                <td>
                    <input type="text" name="user_email" onChange={handleInputChange} />
                </td>
            </tr>
            <tr>
                <td>user_dob</td>
                <td>
                    <input type="text" name="user_dob"  onChange={handleInputChange}/>
                </td>
            </tr>
            <tr>
                <td>gender</td>
                <td>
                    <select name="gender" onChange={handleInputChange}>
                        <option value={" "}>-Select-</option>
                        <option value={"male"}>male</option>
                        <option value={"female"}>female</option>

                    </select>
                    

                </td>
            </tr>
            <tr>
                <td>password</td>
                <td>
                    <input type="password" name="password"  onChange={handleInputChange}/>
                </td>
            </tr>

            <tr>
            <td colSpan={2}>
                <button type="submit">Registration</button>
              </td>
            </tr>


            <tr>
                <td colSpan={2}  align='center'>
                       If already Register <a href='login'>Login Here</a>
                </td>

            </tr>

         </table>
         </form>         
    </div>
  )
}

export default Registration




/*import React from 'react';
import axios from 'axios';
import { useState } from 'react';

const Registration = () => {
  const [userdt, setUserdt] = useState({
    user_name: '',
    user_email: '',
    user_dob: '',
    gender: '',
    password: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserdt({
      ...userdt,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (!userdt.user_name || !userdt.user_email || !userdt.gender || !userdt.user_dob || !userdt.password) {
      console.log('Please fill out all fields');
      return;
    }

    try {
      console.log('Submitting data:', userdt);
      const res = await axios.post('http://127.0.0.1:8000/api/user/adduser', userdt);
      console.log('Response:', res);
      console.log('Form submitted:', userdt);
    } catch (error) {
      console.error('Error:', error.response ? error.response.data : error.message);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <table align="center">
          <tbody>
            <tr>
              <td>Username</td>
              <td>
                <input type="text" name="user_name" onChange={handleInputChange} />
              </td>
            </tr>
            <tr>
              <td>user_email</td>
              <td>
                <input type="text" name="user_email" onChange={handleInputChange} />
              </td>
            </tr>
            <tr>
              <td>user_dob</td>
              <td>
                <input type="text" name="user_dob" onChange={handleInputChange} />
              </td>
            </tr>
            <tr>
              <td>gender</td>
              <td>
                <select name="gender" onChange={handleInputChange}>
                  <option value="">-Select-</option>
                  <option value="male">male</option>
                  <option value="female">female</option>
                </select>
              </td>
            </tr>
            <tr>
              <td>password</td>
              <td>
                <input type="password" name="password" onChange={handleInputChange} />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit">Registration</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default Registration;

*/
