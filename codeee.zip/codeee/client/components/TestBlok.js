import React from 'react'
import  "./TestBlock.css";
import { BlogButton, BlogPara } from '../CommonElements';


const TestBlok = () => {

     

      const pStyle= {
        color : "blue",
        fontSize: "20px"
      }

  return (
    <div>
      <p style={pStyle}>Hello</p>

      <p className='myParagraph'> This is from components</p>

      <BlogButton> Test Button </BlogButton>

      <BlogPara>testing miltiple </BlogPara>

    </div>
  )
}

export default TestBlok
