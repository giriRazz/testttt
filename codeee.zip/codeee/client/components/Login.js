import React from 'react'
import axios from 'axios'
import  { useState } from 'react';


const Login = () => {

  const [logindt, setLogindt] = useState({
    user_email: '',
    password: '',
  });




const handleInputChange = (e) => {
const { name, value } = e.target;
setLogindt({
  ...logindt,
  [name]: value,
});
};

const handleSubmit = async(e) =>{
e.preventDefault();

try {
    const res = await axios.post(`http://localhost:8000/api/user/userlogin`,logindt);

    console.log(res)
   
} catch (error) {
    console.log(error)
}
}



  return (
    <div>
 <form onSubmit={handleSubmit}>
         <table align='center'>
          
            <tr>
                <td>user_email</td>
                <td>
                    <input type="text" name="user_email" onChange={handleInputChange} />
                </td>
            </tr>
          
   
            <tr>
                <td>password</td>
                <td>
                    <input type="password" name="password"  onChange={handleInputChange}/>
                </td>
            </tr>

            <tr>
            <td colSpan={2}>
                <button type="submit">Login</button>
              </td>
            </tr>

         </table>
         </form>   
    </div>
  )
}

export default Login
