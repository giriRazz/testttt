const mongoose = require(`mongoose`)

require(`dotenv`).config()
const db_uri = process.env.DB_URI;

mongoose.connect(db_uri)


/* mongoose.connect('mongodb://localhost:27017/mydatabase', {
  }).then(() => {
    console.log('Connected to MongoDB');
  }).catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });
 */



mongoose.connection.on(`connected`,()=>{
    console.log(`connected to the MOngoDB`);

})

mongoose.connection.on(`error`,(error)=>{
       console.error("Connecttion Error",error);
       //console.log("connted to the MOngoDB not");

})  

module.exports = mongoose; 