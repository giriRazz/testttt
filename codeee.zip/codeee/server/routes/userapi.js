const bcrypt = require(`bcryptjs`)
const jwt = require(`jsonwebtoken`)
const express = require(`express`)
const router = express.Router()
const path = require(`path`)
const multer = require(`multer`)
const User = require(`../models/user`)

const SECRET_KEY = "nfjskdhfs";


const storage = multer.diskStorage({
       destination:`./uploads`,
       filename:function(req,file, cb){
               cb(null,file.filename+Date.now()+".png")
       }

})

const upload = multer({
storage:storage,
limits:{fileSize:10000000}

})


router.post(`/uploadsimage`,upload.single(`profile_pic`),(req,res)=>{
       res.json({"msg":"File uploaded Sucessfully"})

})


//http://localhost:8000/api/user/adduser
router.post(`/adduser`,async(req,res)=>{


    try{

        const newUser = new User({
            user_name :req.body.user_name,
            user_email :req.body.user_email,
            user_dob :req.body.user_dob,
            gender :req.body.gender,
            password: await bcrypt.hash(req.body.password,12)
        })
    
        const saveUser = await newUser.save()
        res.json(saveUser)

    }catch (error){
         res.status(500).json({"error":error})

    }


})

//http://localhost:8000/api/user/userlogin
router.post(`/userlogin`,async(req,res)=>{

      const email = req.body.user_email;
      const password = req.body.password;

    try{

       const login = await User.findOne({user_email:email})
       if(!login){
         return res.json({"msg": "Email not found"})
       }else{
          if(await bcrypt.compare(password,login.password)){
             const token = jwt.sign({userID:login._id},SECRET_KEY,{expiresIn:`1hr`})
              return res.json({"Msg": "Login Sucess", token} )
          }else{
            return res.json({"Msg": "password is wrong", token})
          }
       }

    }catch (error){
         res.status(500).json({"error":error})

    }


})







//http://localhost:8000/api/user/viewUser
router.get(`/viewUser`,async(req,res) => {

      try {
        
        const users = await User.find()
        res.json(users);


      } catch (error) {
        res.status(500).json({"Error":error})
      }

})



//http://localhost:8000/api/user/singleuser/324234
router.get(`/singleuser/:userid`, async(req,res) => {

    const uid = req.params.userid
    
    try {
        const users = await User.findById(uid);
        res.json(users);
    } catch (error) {
        res.status(500).json({"Error":error})
    }
})



//http://localhost:8000/api/user/updateuser/324234

router.put(`/updateuser/:userid`, async(req,res) => {

    const uid = req.params.userid
    
    try {
        const users = await User.findByIdAndUpdate(
            uid,
            {$set:req.body},
            {new:true}
        )
        res.json(users)
    } catch (error) {
        res.status(500).json({"Error":error})
    }
})



//http://localhost:8000/api/user/deleteuser/324234

router.delete(`/deleteuser/:userid`, async(req,res) => {

    const uid = req.params.userid
    
    try {
        const users = await User.findOneAndDelete(uid)
        res.status(200).json({"message": "user has deleted sucessfully","sts":"1"})
    } catch (error) {
        res.status(500).json({"Error":error})
    }
})



module.exports = router;
